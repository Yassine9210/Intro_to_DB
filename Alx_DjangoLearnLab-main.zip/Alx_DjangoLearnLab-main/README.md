# LibraryProject

LibraryProject is a Django application designed for managing a simple library system. This project includes basic functionalities such as creating, reading, updating, and deleting library books.

## Project Structure

The project has the following structure:

AlxDjangoLearnLab/
└── 0x1.Introduction_to_Django/
├── LibraryProject/
│ ├── LibraryProject/
│ │ ├── init.py
│ │ ├── settings.py
│ │ ├── urls.py
│ │ ├── asgi.py
│ │ ├── wsgi.py
│ │ └── README.md
│ ├── bookshelf/
│ │ ├── migrations/
│ │ │ └── init.py
│ │ ├── init.py
│ │ ├── admin.py
│ │ ├── apps.py
│ │ ├── models.py
│ │ ├── tests.py
│ │ ├── views.py
│ │ ├── create.md
│ │ ├── update.md
│ │ ├── retrieve.md
│ │ ├── delete.md
│ │ └── CRUD_operations.md
│ ├── manage.py
│ └── README.md
├── .gitignore
└── venv/

